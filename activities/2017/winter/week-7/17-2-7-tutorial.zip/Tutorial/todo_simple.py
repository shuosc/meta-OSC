
from flask import Flask, request
from flask import render_template
from flask import redirect
app = Flask(__name__)

TASKS = []

class Task():
    def __init__(self, content):
        self.content = content
        self.done = False
    def __repr__(self):
        return '<Content %s>' % self.content

@app.route('/')
def tasks_list():
    tasks = TASKS
    return render_template('list_simple.html', tasks=tasks)


@app.route('/task', methods=['POST'])
def add_task():
    content = request.form['content']
    if not content:
        return 'Error'
    task = Task(content)
    TASKS.append(task)
    return redirect('/')


if __name__ == '__main__':
    app.run(host="0.0.0.0")