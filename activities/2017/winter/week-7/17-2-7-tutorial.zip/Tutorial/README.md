* 安装好Python3.6环境
* 安装 Flask，flask_sqlalchemy
    `pip install Flask flask_sqlalchemy -i https://pypi.douban.com/simple`
* 分别运行目录下的五个 .py 文件 在浏览器中打开 localhost:5000 查看效果