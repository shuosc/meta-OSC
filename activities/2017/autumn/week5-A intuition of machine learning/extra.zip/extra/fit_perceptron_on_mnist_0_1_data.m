clear;
load mnist_0_1_x.txt
load mnist_0_1_y.txt

hold on;

%data initialization
alpha = 0.00001;

rand_index = randperm(1000);
rand_index = rand_index(1: 800);

X = [ones(800, 1) mnist_0_1_x(rand_index, :)];
Y = mnist_0_1_y(rand_index);


W = rand(401, 1);

% training
for iteration = 1:50000
    %compute derivative
    Y_X = sign(X * W);
    M = X(Y_X ~= Y, :);
    delta_w = M' * (M * W);
    
    %update parameters
    W = W - alpha * delta_w;
end

anti_rand_index = setdiff(1:1000, rand_index);

X_validate = [ones(200, 1) mnist_0_1_x(anti_rand_index, :)];
Y_validate = mnist_0_1_y(anti_rand_index);

sub_rand_index = randperm(200);
X_validate = [X_validate(sub_rand_index, :)];
Y_validate = Y_validate(sub_rand_index);

Y_X_validate = sign(X_validate * W);

correct_count = 0;
error_count = 0;
for i=1:200
    if Y_X_validate(i) == Y_validate(i)
        correct_count = correct_count + 1;
    else
        error_count = error_count + 1;
    end
    large_image = imresize(reshape(X_validate(i:i, 2: 401), [20, 20]) , 30);
    imshow(large_image);
    xlabel([num2str(Y_X_validate(i) == 1),...
        ', correct count:', num2str(correct_count),...
        ', error count:',num2str(error_count)], 'FontSize', 24);
    pause(0.1)
end