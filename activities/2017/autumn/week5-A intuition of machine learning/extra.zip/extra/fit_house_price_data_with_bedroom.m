clear;
run('E:\Academy\ML-Course\A intuition of machine learning\draw_house_price_data_with_bedroom.m')

x_range = 0.2:0.01:1.8;
y_range = 0.8:0.02:4.0;
[x_, y_] = meshgrid(x_range, y_range);

mesh(x_, y_, 6.327 * x_ + 0.01874 * y_ - 0.8298);