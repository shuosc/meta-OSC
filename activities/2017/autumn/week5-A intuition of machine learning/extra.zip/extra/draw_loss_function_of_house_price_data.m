clear;
load('house_price.mat')

w_range = 0.53:0.002:0.73;
b_range = -28:0.4:12;
J_ = zeros(101, 101);

for i=1:101
    for j=1:101
        J_(i:i, j:j) = sum(  ...
        (w_range(i) * x + b_range(j) - y) .^ 2  ...
        );
    end
end

surf(w_range, b_range, J_)
% contour(b_range, w_range, J_, 300)