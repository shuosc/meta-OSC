clear;
load('house_price.mat')
scatter(x, y);
hold on;

% data initialization
alpha = 0.00000006;
W = [0; 0.7];
X = [ones(size(x, 1), 1) x];
Y = y;

x_axis = 0:1:150;
y_axis = W(2) * x_axis + W(1); 
h = plot(x_axis, y_axis);
pause(5);
delete(h);

% training
for iteration = 1:75
    delta_W = X' * X * W - X' * Y;
    W = W - alpha * delta_W;
    
    x_axis = 0:1:150;
    y_axis = W(2) * x_axis + W(1); 
    h = plot(x_axis, y_axis, 'b');
    pause(0.1);
    delete(h);
end

x_axis = 0:1:150;
y_axis = W(2) * x_axis + W(1); 
plot(x_axis, y_axis, 'b', 'LineWidth', 2);

pause(5)
title('However this is not a optimal solution...', 'FontSize', 24)
pause(5)

W = inv((X' * X)) * X' * Y;
x_axis = 0:1:150;
y_axis = W(2) * x_axis + W(1); 
plot(x_axis, y_axis, 'r', 'LineWidth', 2);

pause(5)
title('Let us check the Loss Function', 'FontSize', 24)
pause(3)
clf;
run('E:\Academy\ML-Course\A intuition of machine learning\draw_loss_function_of_house_price_data.m')
