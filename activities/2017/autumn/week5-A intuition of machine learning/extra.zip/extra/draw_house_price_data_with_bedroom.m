clear;
load('house_price_with_bedroom.mat')

figure1 = figure;
axes1 = axes('Parent',figure1);
hold(axes1,'on');

scatter3(y, z, x);
xlabel('Arear/100m^2','FontSize',22)
ylabel('Bedrooms/number','FontSize',22)
zlabel('Price/million RMB','FontSize',22)
grid(axes1,'on');

set(axes1,'FontSize',20);