
clear;
load('tumor_data.mat');
scatter(benign_size, benign_smooth, 'b', 'O');
hold on;
scatter(cancer_size, cancer_smooth, 'r', 'x');


%data initialization
alpha = 0.0001;
w_1 = 0.1;
w_2 = 0.1;
b = 0;
x_1 = [benign_size; cancer_size];
x_2 = [benign_smooth; cancer_smooth];
y = [-ones(size(benign_size, 1), 1); ones(size(cancer_size, 1), 1)];
m = size(x_1, 1);

x_1_axis = 0:0.01:5;
x_2_axis = - (b + w_1 * x_1_axis) / w_2;
h = plot(x_1_axis, x_2_axis);

pause(5);
delete(h);

% training
for iteration = 1:100
    %initialize derivative
    delta_w_1 = 0;
    delta_w_2 = 0;
    delta_b = 0;
    
    %compute derivative
    for point_index = 1:m
        if sign(w_1 * x_1(point_index) + ...
                w_2 * x_2(point_index) + b) ~= y(point_index)
            delta_w_1 = delta_w_1 - y(point_index) * x_1(point_index);
            delta_w_2 = delta_w_2 - y(point_index) * x_2(point_index);
            delta_b = delta_b - y(point_index);
        end
    end
    
    %update parameters
    w_1 = w_1 - alpha * delta_w_1;
    w_2 = w_2 - alpha * delta_w_2;
    b = b - alpha * delta_b;
    
    x_1_axis = 0:0.01:5;
    x_2_axis = - (b + w_1 * x_1_axis) / w_2;
    h = plot(x_1_axis, x_2_axis);
    pause(0.1);
    delete(h);
end

x_1_axis = 0:0.01:5;
x_2_axis = - (b + w_1 * x_1_axis) / w_2;
h = plot(x_1_axis, x_2_axis,'LineWidth', 2);