//
//  ViewController.swift
//  CalculatorDemo
//
//  Created by Jerome Tan on 4/27/18.
//  Copyright © 2018 Jerome Tan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displayLabel: UILabel!
    
    var displayValue: Double {
        get {
            return Double(displayLabel.text!)!
        }
        set {
            displayLabel.text = String(newValue)
        }
    }
    
    private var isTyping = false
    
    @IBAction func digitTapped(_ sender: UIButton) {
        let digit = sender.currentTitle!
        
        if isTyping {
            displayLabel.text! = displayLabel.text! + digit
        } else {
            displayLabel.text = digit
            isTyping = true
        }
    }

    @IBAction func clearTapped(_ sender: UIButton) {
        displayLabel.text = "0"
        isTyping = false
    }
    
    var brain = CalculatorBrain()
    
    @IBAction func operationTapped(_ sender: UIButton) {
        if isTyping {
            brain.setOperand(displayValue)
            isTyping = false
        }
        
        brain.performOperation(sender.currentTitle!)
        
        if let result = brain.result {
            displayValue = result
        }
    }
    
}

